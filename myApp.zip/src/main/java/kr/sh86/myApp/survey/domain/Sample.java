package kr.sh86.myApp.survey.domain;

public class Sample {
	private String tTelNo;
	private String tIs;
	private int adCode;
	private String tSido;
	private String tSigungu;
	private String tDong;
	private String tAddr;
	private String tName;
	private String tSex;
	private String tOld;
	private String tJob;
	private String tEdu;
	private String tReligion;
	private String tSuppparty;
	private String tIsok;
	private int tArsSCnt;
	private int tArsRCnt;
	private String tIndate;
	private String tUpdate;
	private int mpsCode;
	private String tNote1;
	public String gettTelNo() {
		return tTelNo;
	}
	public void settTelNo(String tTelNo) {
		this.tTelNo = tTelNo;
	}
	public String gettIs() {
		return tIs;
	}
	public void settIs(String tIs) {
		this.tIs = tIs;
	}
	public int getAdCode() {
		return adCode;
	}
	public void setAdCode(int adCode) {
		this.adCode = adCode;
	}
	public String gettSido() {
		return tSido;
	}
	public void settSido(String tSido) {
		this.tSido = tSido;
	}
	public String gettSigungu() {
		return tSigungu;
	}
	public void settSigungu(String tSigungu) {
		this.tSigungu = tSigungu;
	}
	public String gettDong() {
		return tDong;
	}
	public void settDong(String tDong) {
		this.tDong = tDong;
	}
	public String gettAddr() {
		return tAddr;
	}
	public void settAddr(String tAddr) {
		this.tAddr = tAddr;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public String gettSex() {
		return tSex;
	}
	public void settSex(String tSex) {
		this.tSex = tSex;
	}
	public String gettOld() {
		return tOld;
	}
	public void settOld(String tOld) {
		this.tOld = tOld;
	}
	public String gettJob() {
		return tJob;
	}
	public void settJob(String tJob) {
		this.tJob = tJob;
	}
	public String gettEdu() {
		return tEdu;
	}
	public void settEdu(String tEdu) {
		this.tEdu = tEdu;
	}
	public String gettReligion() {
		return tReligion;
	}
	public void settReligion(String tReligion) {
		this.tReligion = tReligion;
	}
	public String gettSuppparty() {
		return tSuppparty;
	}
	public void settSuppparty(String tSuppparty) {
		this.tSuppparty = tSuppparty;
	}
	public String gettIsok() {
		return tIsok;
	}
	public void settIsok(String tIsok) {
		this.tIsok = tIsok;
	}
	public int gettArsSCnt() {
		return tArsSCnt;
	}
	public void settArsSCnt(int tArsSCnt) {
		this.tArsSCnt = tArsSCnt;
	}
	public int gettArsRCnt() {
		return tArsRCnt;
	}
	public void settArsRCnt(int tArsRCnt) {
		this.tArsRCnt = tArsRCnt;
	}
	public String gettIndate() {
		return tIndate;
	}
	public void settIndate(String tIndate) {
		this.tIndate = tIndate;
	}
	public String gettUpdate() {
		return tUpdate;
	}
	public void settUpdate(String tUpdate) {
		this.tUpdate = tUpdate;
	}
	public int getMpsCode() {
		return mpsCode;
	}
	public void setMpsCode(int mpsCode) {
		this.mpsCode = mpsCode;
	}
	public String gettNote1() {
		return tNote1;
	}
	public void settNote1(String tNote1) {
		this.tNote1 = tNote1;
	}
	
	@Override
	public String toString() {
		return "Sample [tTelNo=" + tTelNo + ", tIs=" + tIs + ", adCode=" + adCode + ", tSido=" + tSido + ", tSigungu="
				+ tSigungu + ", tDong=" + tDong + ", tAddr=" + tAddr + ", tName=" + tName + ", tSex=" + tSex + ", tOld="
				+ tOld + ", tJob=" + tJob + ", tEdu=" + tEdu + ", tReligion=" + tReligion + ", tSuppparty=" + tSuppparty
				+ ", tIsok=" + tIsok + ", tArsSCnt=" + tArsSCnt + ", tArsRCnt=" + tArsRCnt + ", tIndate=" + tIndate
				+ ", tUpdate=" + tUpdate + ", mpsCode=" + mpsCode + ", tNote1=" + tNote1 + "]";
	}
	
	
}

package kr.sh86.myApp.survey.domain;

public class BioResponse {
	private int no;
	private int userNo;
	private String q1;
	private String q1c;
	private String q1Fir;
	private String q1Sec;
	private String q1Thi;
	private String q2;
	private String q2c;
	private String q2Fir;
	private String q2Sec;
	private String q2Thi;
	private String q2Etc;
	private String q3;
	private String q3c;
	private String q3Fir;
	private String q3Sec;
	private String q3Thi;
	private String q3Etc;
	private String q4;
	private String q4c;
	private String q4Fir;
	private String q4Sec;
	private String q4Thi;
	private String q4Etc;
	private String q5;
	private String q5c;
	private String q5Etc;
	private String q6Etc;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	public String getQ1() {
		return q1;
	}
	public void setQ1(String q1) {
		this.q1 = q1;
	}
	public String getQ1c() {
		return q1c;
	}
	public void setQ1c(String q1c) {
		this.q1c = q1c;
	}
	public String getQ1Fir() {
		return q1Fir;
	}
	public void setQ1Fir(String q1Fir) {
		this.q1Fir = q1Fir;
	}
	public String getQ1Sec() {
		return q1Sec;
	}
	public void setQ1Sec(String q1Sec) {
		this.q1Sec = q1Sec;
	}
	public String getQ1Thi() {
		return q1Thi;
	}
	public void setQ1Thi(String q1Thi) {
		this.q1Thi = q1Thi;
	}
	public String getQ2() {
		return q2;
	}
	public void setQ2(String q2) {
		this.q2 = q2;
	}
	public String getQ2c() {
		return q2c;
	}
	public void setQ2c(String q2c) {
		this.q2c = q2c;
	}
	public String getQ2Fir() {
		return q2Fir;
	}
	public void setQ2Fir(String q2Fir) {
		this.q2Fir = q2Fir;
	}
	public String getQ2Sec() {
		return q2Sec;
	}
	public void setQ2Sec(String q2Sec) {
		this.q2Sec = q2Sec;
	}
	public String getQ2Thi() {
		return q2Thi;
	}
	public void setQ2Thi(String q2Thi) {
		this.q2Thi = q2Thi;
	}
	public String getQ2Etc() {
		return q2Etc;
	}
	public void setQ2Etc(String q2Etc) {
		this.q2Etc = q2Etc;
	}
	public String getQ3() {
		return q3;
	}
	public void setQ3(String q3) {
		this.q3 = q3;
	}
	public String getQ3c() {
		return q3c;
	}
	public void setQ3c(String q3c) {
		this.q3c = q3c;
	}
	public String getQ3Fir() {
		return q3Fir;
	}
	public void setQ3Fir(String q3Fir) {
		this.q3Fir = q3Fir;
	}
	public String getQ3Sec() {
		return q3Sec;
	}
	public void setQ3Sec(String q3Sec) {
		this.q3Sec = q3Sec;
	}
	public String getQ3Thi() {
		return q3Thi;
	}
	public void setQ3Thi(String q3Thi) {
		this.q3Thi = q3Thi;
	}
	public String getQ3Etc() {
		return q3Etc;
	}
	public void setQ3Etc(String q3Etc) {
		this.q3Etc = q3Etc;
	}
	public String getQ4() {
		return q4;
	}
	public void setQ4(String q4) {
		this.q4 = q4;
	}
	public String getQ4c() {
		return q4c;
	}
	public void setQ4c(String q4c) {
		this.q4c = q4c;
	}
	public String getQ4Fir() {
		return q4Fir;
	}
	public void setQ4Fir(String q4Fir) {
		this.q4Fir = q4Fir;
	}
	public String getQ4Sec() {
		return q4Sec;
	}
	public void setQ4Sec(String q4Sec) {
		this.q4Sec = q4Sec;
	}
	public String getQ4Thi() {
		return q4Thi;
	}
	public void setQ4Thi(String q4Thi) {
		this.q4Thi = q4Thi;
	}
	public String getQ4Etc() {
		return q4Etc;
	}
	public void setQ4Etc(String q4Etc) {
		this.q4Etc = q4Etc;
	}
	public String getQ5() {
		return q5;
	}
	public void setQ5(String q5) {
		this.q5 = q5;
	}
	public String getQ5c() {
		return q5c;
	}
	public void setQ5c(String q5c) {
		this.q5c = q5c;
	}
	public String getQ5Etc() {
		return q5Etc;
	}
	public void setQ5Etc(String q5Etc) {
		this.q5Etc = q5Etc;
	}
	public String getQ6Etc() {
		return q6Etc;
	}
	public void setQ6Etc(String q6Etc) {
		this.q6Etc = q6Etc;
	}
	@Override
	public String toString() {
		return "BioResponse [no=" + no + ", userNo=" + userNo + ", q1=" + q1 + ", q1c=" + q1c + ", q1Fir=" + q1Fir
				+ ", q1Sec=" + q1Sec + ", q1Thi=" + q1Thi + ", q2=" + q2 + ", q2c=" + q2c + ", q2Fir=" + q2Fir
				+ ", q2Sec=" + q2Sec + ", q2Thi=" + q2Thi + ", q2Etc=" + q2Etc + ", q3=" + q3 + ", q3c=" + q3c
				+ ", q3Fir=" + q3Fir + ", q3Sec=" + q3Sec + ", q3Thi=" + q3Thi + ", q3Etc=" + q3Etc + ", q4=" + q4
				+ ", q4c=" + q4c + ", q4Fir=" + q4Fir + ", q4Sec=" + q4Sec + ", q4Thi=" + q4Thi + ", q4Etc=" + q4Etc
				+ ", q5=" + q5 + ", q5c=" + q5c + ", q5Etc=" + q5Etc + ", q6Etc=" + q6Etc + "]";
	}
	
	
}

package kr.sh86.myApp.survey.domain;

public class Response {
	private int resNo;
	private int userNo;
	private String regDate;
	private String sex;
	private String grade;
	private String q1c;
	private String q1k;
	private String q1m;
	private String q1Etc;
	private String q2c;
	private String q2k;
	private String q2m;
	private String q3c;
	private String q3k;
	private String q3m;
	private String q4c;
	private String q4k;
	private String q4m;
	private String q5c;
	private String q5k;
	private String q5m;
	private String q6c;
	private String q6k;
	private String q6m;
	private String q6Etc;
	private String q7c;
	private String q7k;
	private String q7m;
	private String q8c;
	private String q8k;
	private String q8m;
	private String q9c;
	private String q9k;
	private String q9m;
	private String q10c;
	private String q10k;
	private String q10m;
	private String q11c;
	private String q11k;
	private String q11m;
	private String q11Etc;
	private String q12c;
	private String q12k;
	private String q12m;	
	private String q13c;
	private String q13k;
	private String q13m;
	private String q14c;
	private String q14k;
	private String q14m;
	private String q14Etc;
	private String q15k;
	private String q15m;
	private String q16k;
	private String q16m;
	private String q16Etc;
	private String q17k;
	private String q17m;	
	private String q18k;
	private String q18m;
	private String q18Etc;
	private String q19k;
	private String q19m;	
	private String q20k;
	private String q20m;
	private String q20Etc;
	private String q21k;
	private String q21m;
	private String q21Etc;
	private String q22k;
	private String q22m;
	private String q23k;
	private String q23m;
	private String q23Etc;
	private String q24k;
	private String q24m;
	private String q25k;
	private String q25m;	
	private String q26k;
	private String q26m;
	private String q26Etc;
	private String q27k;
	private String q27m;	
	private String q28k;
	private String q28m;
	private String q29k;
	private String q29m;
	private String q30k;
	private String q30m;
	private String q30Etc;
	private String q31Etc;
	public int getResNo() {
		return resNo;
	}
	public void setResNo(int resNo) {
		this.resNo = resNo;
	}
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getQ1c() {
		return q1c;
	}
	public void setQ1c(String q1c) {
		this.q1c = q1c;
	}
	public String getQ1k() {
		return q1k;
	}
	public void setQ1k(String q1k) {
		this.q1k = q1k;
	}
	public String getQ1m() {
		return q1m;
	}
	public void setQ1m(String q1m) {
		this.q1m = q1m;
	}
	public String getQ1Etc() {
		return q1Etc;
	}
	public void setQ1Etc(String q1Etc) {
		this.q1Etc = q1Etc;
	}
	public String getQ2c() {
		return q2c;
	}
	public void setQ2c(String q2c) {
		this.q2c = q2c;
	}
	public String getQ2k() {
		return q2k;
	}
	public void setQ2k(String q2k) {
		this.q2k = q2k;
	}
	public String getQ2m() {
		return q2m;
	}
	public void setQ2m(String q2m) {
		this.q2m = q2m;
	}
	public String getQ3c() {
		return q3c;
	}
	public void setQ3c(String q3c) {
		this.q3c = q3c;
	}
	public String getQ3k() {
		return q3k;
	}
	public void setQ3k(String q3k) {
		this.q3k = q3k;
	}
	public String getQ3m() {
		return q3m;
	}
	public void setQ3m(String q3m) {
		this.q3m = q3m;
	}
	public String getQ4c() {
		return q4c;
	}
	public void setQ4c(String q4c) {
		this.q4c = q4c;
	}
	public String getQ4k() {
		return q4k;
	}
	public void setQ4k(String q4k) {
		this.q4k = q4k;
	}
	public String getQ4m() {
		return q4m;
	}
	public void setQ4m(String q4m) {
		this.q4m = q4m;
	}
	public String getQ5c() {
		return q5c;
	}
	public void setQ5c(String q5c) {
		this.q5c = q5c;
	}
	public String getQ5k() {
		return q5k;
	}
	public void setQ5k(String q5k) {
		this.q5k = q5k;
	}
	public String getQ5m() {
		return q5m;
	}
	public void setQ5m(String q5m) {
		this.q5m = q5m;
	}
	public String getQ6c() {
		return q6c;
	}
	public void setQ6c(String q6c) {
		this.q6c = q6c;
	}
	public String getQ6k() {
		return q6k;
	}
	public void setQ6k(String q6k) {
		this.q6k = q6k;
	}
	public String getQ6m() {
		return q6m;
	}
	public void setQ6m(String q6m) {
		this.q6m = q6m;
	}
	public String getQ6Etc() {
		return q6Etc;
	}
	public void setQ6Etc(String q6Etc) {
		this.q6Etc = q6Etc;
	}
	public String getQ7c() {
		return q7c;
	}
	public void setQ7c(String q7c) {
		this.q7c = q7c;
	}
	public String getQ7k() {
		return q7k;
	}
	public void setQ7k(String q7k) {
		this.q7k = q7k;
	}
	public String getQ7m() {
		return q7m;
	}
	public void setQ7m(String q7m) {
		this.q7m = q7m;
	}
	public String getQ8c() {
		return q8c;
	}
	public void setQ8c(String q8c) {
		this.q8c = q8c;
	}
	public String getQ8k() {
		return q8k;
	}
	public void setQ8k(String q8k) {
		this.q8k = q8k;
	}
	public String getQ8m() {
		return q8m;
	}
	public void setQ8m(String q8m) {
		this.q8m = q8m;
	}
	public String getQ9c() {
		return q9c;
	}
	public void setQ9c(String q9c) {
		this.q9c = q9c;
	}
	public String getQ9k() {
		return q9k;
	}
	public void setQ9k(String q9k) {
		this.q9k = q9k;
	}
	public String getQ9m() {
		return q9m;
	}
	public void setQ9m(String q9m) {
		this.q9m = q9m;
	}
	public String getQ10c() {
		return q10c;
	}
	public void setQ10c(String q10c) {
		this.q10c = q10c;
	}
	public String getQ10k() {
		return q10k;
	}
	public void setQ10k(String q10k) {
		this.q10k = q10k;
	}
	public String getQ10m() {
		return q10m;
	}
	public void setQ10m(String q10m) {
		this.q10m = q10m;
	}
	public String getQ11c() {
		return q11c;
	}
	public void setQ11c(String q11c) {
		this.q11c = q11c;
	}
	public String getQ11k() {
		return q11k;
	}
	public void setQ11k(String q11k) {
		this.q11k = q11k;
	}
	public String getQ11m() {
		return q11m;
	}
	public void setQ11m(String q11m) {
		this.q11m = q11m;
	}
	public String getQ11Etc() {
		return q11Etc;
	}
	public void setQ11Etc(String q11Etc) {
		this.q11Etc = q11Etc;
	}
	public String getQ12c() {
		return q12c;
	}
	public void setQ12c(String q12c) {
		this.q12c = q12c;
	}
	public String getQ12k() {
		return q12k;
	}
	public void setQ12k(String q12k) {
		this.q12k = q12k;
	}
	public String getQ12m() {
		return q12m;
	}
	public void setQ12m(String q12m) {
		this.q12m = q12m;
	}
	public String getQ13c() {
		return q13c;
	}
	public void setQ13c(String q13c) {
		this.q13c = q13c;
	}
	public String getQ13k() {
		return q13k;
	}
	public void setQ13k(String q13k) {
		this.q13k = q13k;
	}
	public String getQ13m() {
		return q13m;
	}
	public void setQ13m(String q13m) {
		this.q13m = q13m;
	}
	public String getQ14c() {
		return q14c;
	}
	public void setQ14c(String q14c) {
		this.q14c = q14c;
	}
	public String getQ14k() {
		return q14k;
	}
	public void setQ14k(String q14k) {
		this.q14k = q14k;
	}
	public String getQ14m() {
		return q14m;
	}
	public void setQ14m(String q14m) {
		this.q14m = q14m;
	}
	public String getQ14Etc() {
		return q14Etc;
	}
	public void setQ14Etc(String q14Etc) {
		this.q14Etc = q14Etc;
	}
	public String getQ15k() {
		return q15k;
	}
	public void setQ15k(String q15k) {
		this.q15k = q15k;
	}
	public String getQ15m() {
		return q15m;
	}
	public void setQ15m(String q15m) {
		this.q15m = q15m;
	}
	public String getQ16k() {
		return q16k;
	}
	public void setQ16k(String q16k) {
		this.q16k = q16k;
	}
	public String getQ16m() {
		return q16m;
	}
	public void setQ16m(String q16m) {
		this.q16m = q16m;
	}
	public String getQ16Etc() {
		return q16Etc;
	}
	public void setQ16Etc(String q16Etc) {
		this.q16Etc = q16Etc;
	}
	public String getQ17k() {
		return q17k;
	}
	public void setQ17k(String q17k) {
		this.q17k = q17k;
	}
	public String getQ17m() {
		return q17m;
	}
	public void setQ17m(String q17m) {
		this.q17m = q17m;
	}
	public String getQ18k() {
		return q18k;
	}
	public void setQ18k(String q18k) {
		this.q18k = q18k;
	}
	public String getQ18m() {
		return q18m;
	}
	public void setQ18m(String q18m) {
		this.q18m = q18m;
	}
	public String getQ18Etc() {
		return q18Etc;
	}
	public void setQ18Etc(String q18Etc) {
		this.q18Etc = q18Etc;
	}
	public String getQ19k() {
		return q19k;
	}
	public void setQ19k(String q19k) {
		this.q19k = q19k;
	}
	public String getQ19m() {
		return q19m;
	}
	public void setQ19m(String q19m) {
		this.q19m = q19m;
	}
	public String getQ20k() {
		return q20k;
	}
	public void setQ20k(String q20k) {
		this.q20k = q20k;
	}
	public String getQ20m() {
		return q20m;
	}
	public void setQ20m(String q20m) {
		this.q20m = q20m;
	}
	public String getQ20Etc() {
		return q20Etc;
	}
	public void setQ20Etc(String q20Etc) {
		this.q20Etc = q20Etc;
	}
	public String getQ21k() {
		return q21k;
	}
	public void setQ21k(String q21k) {
		this.q21k = q21k;
	}
	public String getQ21m() {
		return q21m;
	}
	public void setQ21m(String q21m) {
		this.q21m = q21m;
	}
	public String getQ21Etc() {
		return q21Etc;
	}
	public void setQ21Etc(String q21Etc) {
		this.q21Etc = q21Etc;
	}
	public String getQ22k() {
		return q22k;
	}
	public void setQ22k(String q22k) {
		this.q22k = q22k;
	}
	public String getQ22m() {
		return q22m;
	}
	public void setQ22m(String q22m) {
		this.q22m = q22m;
	}
	public String getQ23k() {
		return q23k;
	}
	public void setQ23k(String q23k) {
		this.q23k = q23k;
	}
	public String getQ23m() {
		return q23m;
	}
	public void setQ23m(String q23m) {
		this.q23m = q23m;
	}
	public String getQ23Etc() {
		return q23Etc;
	}
	public void setQ23Etc(String q23Etc) {
		this.q23Etc = q23Etc;
	}
	public String getQ24k() {
		return q24k;
	}
	public void setQ24k(String q24k) {
		this.q24k = q24k;
	}
	public String getQ24m() {
		return q24m;
	}
	public void setQ24m(String q24m) {
		this.q24m = q24m;
	}
	public String getQ25k() {
		return q25k;
	}
	public void setQ25k(String q25k) {
		this.q25k = q25k;
	}
	public String getQ25m() {
		return q25m;
	}
	public void setQ25m(String q25m) {
		this.q25m = q25m;
	}
	public String getQ26k() {
		return q26k;
	}
	public void setQ26k(String q26k) {
		this.q26k = q26k;
	}
	public String getQ26m() {
		return q26m;
	}
	public void setQ26m(String q26m) {
		this.q26m = q26m;
	}
	public String getQ26Etc() {
		return q26Etc;
	}
	public void setQ26Etc(String q26Etc) {
		this.q26Etc = q26Etc;
	}
	public String getQ27k() {
		return q27k;
	}
	public void setQ27k(String q27k) {
		this.q27k = q27k;
	}
	public String getQ27m() {
		return q27m;
	}
	public void setQ27m(String q27m) {
		this.q27m = q27m;
	}
	public String getQ28k() {
		return q28k;
	}
	public void setQ28k(String q28k) {
		this.q28k = q28k;
	}
	public String getQ28m() {
		return q28m;
	}
	public void setQ28m(String q28m) {
		this.q28m = q28m;
	}
	public String getQ29k() {
		return q29k;
	}
	public void setQ29k(String q29k) {
		this.q29k = q29k;
	}
	public String getQ29m() {
		return q29m;
	}
	public void setQ29m(String q29m) {
		this.q29m = q29m;
	}
	public String getQ30k() {
		return q30k;
	}
	public void setQ30k(String q30k) {
		this.q30k = q30k;
	}
	public String getQ30m() {
		return q30m;
	}
	public void setQ30m(String q30m) {
		this.q30m = q30m;
	}
	public String getQ30Etc() {
		return q30Etc;
	}
	public void setQ30Etc(String q30Etc) {
		this.q30Etc = q30Etc;
	}
	public String getQ31Etc() {
		return q31Etc;
	}
	public void setQ31Etc(String q31Etc) {
		this.q31Etc = q31Etc;
	}
	@Override
	public String toString() {
		return "Response [resNo=" + resNo + ", userNo=" + userNo + ", regDate=" + regDate + ", sex=" + sex + ", grade="
				+ grade + ", q1c=" + q1c + ", q1k=" + q1k + ", q1m=" + q1m + ", q1Etc=" + q1Etc + ", q2c=" + q2c
				+ ", q2k=" + q2k + ", q2m=" + q2m + ", q3c=" + q3c + ", q3k=" + q3k + ", q3m=" + q3m + ", q4c=" + q4c
				+ ", q4k=" + q4k + ", q4m=" + q4m + ", q5c=" + q5c + ", q5k=" + q5k + ", q5m=" + q5m + ", q6c=" + q6c
				+ ", q6k=" + q6k + ", q6m=" + q6m + ", q6Etc=" + q6Etc + ", q7c=" + q7c + ", q7k=" + q7k + ", q7m="
				+ q7m + ", q8c=" + q8c + ", q8k=" + q8k + ", q8m=" + q8m + ", q9c=" + q9c + ", q9k=" + q9k + ", q9m="
				+ q9m + ", q10c=" + q10c + ", q10k=" + q10k + ", q10m=" + q10m + ", q11c=" + q11c + ", q11k=" + q11k
				+ ", q11m=" + q11m + ", q11Etc=" + q11Etc + ", q12c=" + q12c + ", q12k=" + q12k + ", q12m=" + q12m
				+ ", q13c=" + q13c + ", q13k=" + q13k + ", q13m=" + q13m + ", q14c=" + q14c + ", q14k=" + q14k
				+ ", q14m=" + q14m + ", q14Etc=" + q14Etc + ", q15k=" + q15k + ", q15m=" + q15m + ", q16k=" + q16k
				+ ", q16m=" + q16m + ", q16Etc=" + q16Etc + ", q17k=" + q17k + ", q17m=" + q17m + ", q18k=" + q18k
				+ ", q18m=" + q18m + ", q18Etc=" + q18Etc + ", q19k=" + q19k + ", q19m=" + q19m + ", q20k=" + q20k
				+ ", q20m=" + q20m + ", q20Etc=" + q20Etc + ", q21k=" + q21k + ", q21m=" + q21m + ", q21Etc=" + q21Etc
				+ ", q22k=" + q22k + ", q22m=" + q22m + ", q23k=" + q23k + ", q23m=" + q23m + ", q23Etc=" + q23Etc
				+ ", q24k=" + q24k + ", q24m=" + q24m + ", q25k=" + q25k + ", q25m=" + q25m + ", q26k=" + q26k
				+ ", q26m=" + q26m + ", q26Etc=" + q26Etc + ", q27k=" + q27k + ", q27m=" + q27m + ", q28k=" + q28k
				+ ", q28m=" + q28m + ", q29k=" + q29k + ", q29m=" + q29m + ", q30k=" + q30k + ", q30m=" + q30m
				+ ", q30Etc=" + q30Etc + ", q31Etc=" + q31Etc + "]";
	}
	
}
